        package FlappyBird;

import javax.swing.*;

public class FlappyBirdMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Window::new);
    }
}
