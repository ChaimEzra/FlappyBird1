package FlappyBird;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

import static FlappyBird.Window.getWindowHeight;

import static FlappyBird.Window.getWindowWidth;



public class Pipes extends JPanel {
    private Image upPipe;
    private Image daunePipe;


    public final int WIDTH = 70;
    public int pipeX;
    public int pipeX1;


    static Random random = new Random();

    public int skyHeight;
    public int floorHeight;
//    public int skyHeight1;
//    public int floorHeight1;


    public Pipes(int pipeX) {
        upPipe = Toolkit.getDefaultToolkit().getImage("C:\\Users\\eliys\\eclipse-workspace\\FlappyBird1\\.idea\\image1\\up.png");
        daunePipe = Toolkit.getDefaultToolkit().getImage("C:\\Users\\eliys\\eclipse-workspace\\FlappyBird1\\.idea\\image1\\20230509_003012.png");


        this.pipeX += getWindowWidth();
        this.pipeX+=pipeX;
        //this.pipeX1 += getWindowWidth() + 223;


        new Thread(() -> {
            while (true) {
                this.pipeX--;
             //   this.pipeX1--;


                if (this.pipeX < -70) {
                    this.pipeX = getWindowWidth();
                    skyHeight = random.nextInt(50,301) + 50;  // Random height between 50 and 350
                    floorHeight = 350 - skyHeight;
                }
//                if (this.pipeX1 < -70) {
//                    this.pipeX1 = getWindowWidth();
//                    skyHeight1 = random.nextInt(301) + 50;  // Random height between 50 and 350
//                    floorHeight1 = 350 - skyHeight1;
//                }
                try {
                    Thread.sleep(9);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }



    public void paint(Graphics g) {
        g.drawImage(daunePipe, pipeX,getWindowHeight()-137-floorHeight, WIDTH, floorHeight, this);

        g.drawImage(upPipe, pipeX,0, WIDTH, skyHeight, this);

//
//        g.drawImage(upPipe, pipeX1,0, WIDTH, skyHeight1, this);
//
//        g.drawImage(daunePipe, pipeX1,getWindowHeight()-137-floorHeight1, WIDTH, floorHeight1, this);




    }
}
