package FlappyBird;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GameSans extends JPanel implements KeyListener {
    private int birdY;
    private int gravity;
    private Pipes pipes;

    private Pipes pipes1;
    private Pipes pipes2;

    private Pipes pipes3;
    private Image image;
    private Image imageBackground;





    public GameSans() {
        image = Toolkit.getDefaultToolkit().getImage("C:\\Users\\eliys\\eclipse-workspace\\FlappyBird1\\.idea\\image1\\new_bird1-removebg-preview.png");
        imageBackground = Toolkit.getDefaultToolkit().getImage("C:\\Users\\eliys\\eclipse-workspace\\FlappyBird1\\.idea\\image1\\backgraund.jpg");

        birdY = getHeight() / 2;
        gravity = 0;

        this.pipes=new Pipes(0);
        this.pipes1=new Pipes(-223);
        this.pipes=new Pipes(400);
        this.pipes1=new Pipes(600);



        setFocusable(true);
        addKeyListener(this);

        new Thread(() -> {
            while (true) {
                gravity++;
                birdY += gravity;

                if (birdY > getHeight() - 130)
                    birdY = getHeight() - 130;
                if (birdY < 0)
                    birdY = 0;


                repaint();

                try {
                    Thread.sleep(45);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();


    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(imageBackground, 0, 0, getWidth(), getHeight() - 100, this);

        g.setColor(Color.orange);
        g.fillRect(0, getHeight() - 100, getWidth(), 100);

        g.drawImage(image, getWidth() / 2-15, birdY, 40, 30, this);

        pipes.paint(g);
        pipes1.paint(g);

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            gravity = -8;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {


    }
}
